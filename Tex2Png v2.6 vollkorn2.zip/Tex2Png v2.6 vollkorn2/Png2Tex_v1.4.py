
#   Texture Converter by            vollkorn2   (YT: SoGTA in UE5)
#   Supported                       .png/.PNG   Tex Type: 01 / (06) / 11 / 14 / 15 / 16 / 17 / 18
#   Not Supported                   PNGs with Interlace
#   Angel Game Engine Textures 	    Angel Studios (now: Rockstar San Diego)

#   v1.4    05.02.2026
#   BugFix: Create Auto MipMaps if FlagList.txt is "Missing"
#   Doc:    FlagList.txt must be moved to "Input   PNG" by hand (Tex2Png does save this File in "Output   PNG") otherwise it will be ignored.

#   v1.3    26.10.2025
#   Add Number of MipMaps to FlagList.txt

#   v1.2    15.10.2025
#   Read FlagList.txt

#   v1.1    26.09.2025
#   Custom MipMap Support
#   Better Documentation

#   v1.0    vollkorn2 
#   Copy of Tex2Png
#   Read PNGs
#   Get TexType based on PNG Situation
#   WriteTex Functions
#   Write FileHead
#   Write to File
#   Write custom Garbage and Flags


# Games Tested:
# Red Dead Revolver (Partly)

# **********************************************************************************************************************************************************************************************

# All Paths must end with "/" and all other Slashes must be also this direction "/"
PathToSelf = "D:/This/Could/Be/Your/FilePath/Leading/To/Tex2Png/"    # Folderpath to TexToPng Script

FileExt = ".tex"            # Choose between ".tex" and ".xtex"
MirrorV = False             # Correct the Reversed Reading of AGE .tex files (Same Setting as Tex2Png / False = PNGs are already inverted, True = PNGs are not Inverted)
PrintFileHead = False       # Each .png File has Resolution, Greyscale, Alpha, Bitdepth, Planes and Interlace. Here you can Print these Values to the System Console. Usefull for Analysing.

# AutoCreateMipMaps or Custom MipMaps:
# False = If you Exported MipMaps with Tex2Png or created your own MipMaps you can repack these MipMaps to Tex File
# True  = You don't have any MipMaps as PNG and want to create automatic MipMaps
# Custom MipMaps must have the following name > "TexName_Mip1.png"   /   Png2Tex does Support up to 10 MipMaps (Original PNG included / Mip1 - Mip9)
# Note:   Auto created MipMaps are not perfect but should be enough for most cases (MipMaps will not be created if FlagList.txt has only 1 MipMap)
# Note:   FlagList.txt must be moved to "Input   PNG" by hand (Tex2Png does save this File in "Output   PNG") otherwise it will be ignored.
AutoCreateMipMaps = True 

# Custom Flags - for Testing only (Always 8 Bits!!!)    Flag1 == "00001000" (used in Midnight Club 2 Road-Textures for Alpha Manipulation, I guess)
# Custom Flags will be ignored if "FlagList.txt" is found in "Input PNG" Folder
Garbage1 = "00000000"
Garbage2 = "00000000"
Flag1 = "00000000"
Flag2 = "00000000"
Flag3 = "00000000"
Flag4 = "00000000"


# **********************************************************************************************************************************************************************************************

import os       # Read/Write Files in Operating System
import sys      # Add Temporary SystemPath to find Modules shipped with TexToPng
sys.path = [PathToSelf+"3rd Party Modules/"]      # This makes PyPNG / DXT_Decompress run without installation
import png      # Read PNG Files
import struct   # Read Binary Files
import re       # 

# 18 Total TexTypes
# 01 02 06 08 09 10 11 14 15 16 17 18 19 20 21 22 24 26     Total
# 01    06 08       11 14 15 16 17 18          22 24 26     Tex2Png
# 01    06          11 14 15 16 17 18                       Png2Tex
# Stride = ByteDepth per Pixel (RGBA = Stride 4) / -2 means Stride 0.5 (4 bit Total)

#Tex Type: 01       True        True        P8          Stride 1        8 Bit Index Palette (256 Colors with RGBA as 4 * Int8) Int8 for Indices

#Tex Type: 02       False       False       P8A8        Stride 2        To Be Found !!!     [8 Bit Index Palette (256 Colors with RGBA as 4 * Int8) Int8 for Indices + Int8 for Unique Alpha]

#Tex Type: 06       3/4         True        RGBA4444    Stride 2        RGBA        4 * Int4    (sky.tex has weird Alpha Channel and a big Pink Spot)

#Tex Type: 08       True        Tex11       A8          Stride 1        A           1 * Int8

#Tex Type: 09       False       False       A4I4        Stride 1        To Be Found !!!

#Tex Type: 10       False       False       A8I8        Stride 2        To Be Found !!!

#Tex Type: 11       True        True        A8          Stride 1        A           1 * Int8

#Tex Type: 14       True        True        PA8         Stride 1        8 Bit Index Palette (256 Colors with RGBA as 4 * Int8) Int8 for Indices     with Alpha

#Tex Type: 15       True        True        P4          Stride -2       4 Bit Index Palette (016 Colors with RGBA as 4 * Int8) Int4 for Indices

#Tex Type: 16       True        True        PA4         Stride -2       4 Bit Index Palette (016 Colors with RGBA as 4 * Int8) Int4 for Indices     With Alpha

#Tex Type: 17       True        True        RGB888      Stride 3        RGB         3 * Int8

#Tex Type: 18       True        True        RGBA8888    Stride 4        RGBA        4 * Int8

#Tex Type: 19       False       False       Z16         Stride 2        Depth / To Be Found !!!

#Tex Type: 20       False       False       Z24         Stride 3        Depth / To Be Found !!!

#Tex Type: 21       False       False       Z32         Stride 4        Depth / To Be Found !!!
 
#Tex Type: 22       True        Tex18       DXT1        Stride -2       DXT1 Compressed

#Tex Type: 24       True        Tex18       DXT3        Stride 1        DXT3 Compressed

#Tex Type: 26       True        Tex18       DXT5        Stride 1        DXT5 Compressed

print("*** Start ********************************************************************************")

# 01    06          11 14 15 16 17 18                       Png2Tex

def Write_Tex01():  # Tex01 / 14
    PaletteBlock = b''
    PixelBlock = b''
    # Write Palette ByteBlock
    if len(Palette[0]) == 3:    # Tex01
        TexType = 1
        for RGB in Palette:
            PaletteBlock += struct.pack('<BBBB', RGB[2], RGB[1], RGB[0], 255)       # BGRA
    if len(Palette[0]) == 4:    # Tex14
        TexType = 14
        for RGB in Palette:
            PaletteBlock += struct.pack('<BBBB', RGB[2], RGB[1], RGB[0], RGB[3])    # BGRA
    
    if len(PaletteBlock) < 256:     # Never Tested !!!
        PaletteBlock += bytes[256-len(PaletteBlock)]
    
    # Convert PyPNG-Pixels to Int8 List
    AllPixelList = []
    for MipPixels in MipPixelList:
        NewPixels = list(MipPixels)
        PixelList = []
        for ByteArray in NewPixels:
            for Byte in ByteArray:
                PixelList.append(Byte)
        AllPixelList.append(PixelList)
    #  Write MipMaps ByteBlock
    MipMaps, MipCount = Create_MipMaps(AllPixelList)
    for Mip in MipMaps:
        for Pixel in Mip:
            PixelBlock += struct.pack('<B', Pixel)
    return TexType, PaletteBlock, PixelBlock, MipCount
        


def Write_Tex06():  # Tex06
    TexType = 6
    PaletteBlock = b''
    PixelBlock = b''
    # Convert PyPNG-Pixels to Int8 List
    AllIntList = []
    for MipPixels in MipPixelList:
        NewPixels = list(MipPixels)
        IntList = []
        for ByteArray in NewPixels:
            for Byte in ByteArray:
                IntList.append(Byte)
        AllIntList.append(IntList)
    # Convert IntList to RGBA Pixels
    AllPixelList = []
    for IntList in AllIntList:
        PixelList = []
        for Value in range(len(IntList)//4):
            PixelList.append([IntList[Value*4+0], IntList[Value*4+1], IntList[Value*4+2], IntList[Value*4+3]])
        AllPixelList.append(PixelList)
    #  Write MipMaps ByteBlock
    MipMaps, MipCount = Create_MipMaps(AllPixelList)
    for Mip in MipMaps:
        for Pixel in Mip:
            R = format(Pixel[0]//17, '08b')[4:]     # Get Color Value from Pixel > Divide (from 255 to 15) > Convert to Binary String > Remove 1st Half of Bits
            G = format(Pixel[1]//17, '08b')[4:]
            B = format(Pixel[2]//17, '08b')[4:]
            A = format(Pixel[3]//17, '08b')[4:]
            RG = int(R+G, 2)                # Combine 2 Binary Strings and Convert to Int8
            BA = int(B+A, 2) 
            PixelBlock += struct.pack('<BB', RG, BA)
    return TexType, PaletteBlock, PixelBlock, MipCount


def Write_Tex11():  # Tex11
    TexType = 11
    PaletteBlock = b''
    PixelBlock = b''
    # Convert PyPNG-Pixels to Int8 List
    AllIntList = []
    for MipPixels in MipPixelList:
        NewPixels = list(MipPixels)
        IntList = []
        for ByteArray in NewPixels:
            for Byte in ByteArray:
                IntList.append(Byte)
        AllIntList.append(IntList)   
    # Convert IntList to Alpha Pixels (Remove Greyscale Values)
    AllPixelList = []
    for IntList in AllIntList:
        PixelList = []
        for Value in range(len(IntList)//2):
            PixelList.append(IntList[Value*2+1])  # Get every 2nd Value (0=Grey 1=Alpha)  Tex2Png does Convert Tex08/11 to AlphaMask (Greyscale is unused)
        AllPixelList.append(PixelList)
    #  Write MipMaps ByteBlock
    MipMaps, MipCount = Create_MipMaps(AllPixelList)
    for Mip in MipMaps:
        for Pixel in Mip:
            PixelBlock += struct.pack('<B', Pixel)
    return TexType, PaletteBlock, PixelBlock, MipCount
    

def Write_Tex15():  # Tex15 / 16
    PaletteBlock = b''
    PixelBlock = b''
    # Write Palette ByteBlock
    if len(Palette[0]) == 3:    # Tex15
        TexType = 15
        for RGB in Palette:
            PaletteBlock += struct.pack('<BBBB', RGB[2], RGB[1], RGB[0], 255)       # BGRA
    if len(Palette[0]) == 4:    # Tex16
        TexType = 16
        for RGB in Palette:
            PaletteBlock += struct.pack('<BBBB', RGB[2], RGB[1], RGB[0], RGB[3])    # BGRA
    
    if len(PaletteBlock) < 16:     # Never Tested !!!
        PaletteBlock += bytes[16-len(PaletteBlock)]
    
    # Convert PyPNG-Pixels to Int8 List
    AllPixelList = []
    for MipPixels in MipPixelList:
        NewPixels = list(MipPixels)
        PixelList = []
        for ByteArray in NewPixels:
            for Byte in ByteArray:
                PixelList.append(Byte)
        AllPixelList.append(PixelList)
    #  Write MipMaps ByteBlock
    MipMaps, MipCount = Create_MipMaps(AllPixelList)
    for Mip in MipMaps:
        for Index in range(len(Mip)//2):
            Index1 = format(Mip[Index*2+0], '08b')[4:]      # Get Index Value from MipMap > Convert to Binary String > Remove 1st Half of Bits
            Index2 = format(Mip[Index*2+1], '08b')[4:]
            DoubleIndex = int(Index2+Index1, 2)             # Combine 2 Binary Strings and Convert to Int8      Note: Index 1 and 2 must be reversed (First=Index2 Second=Index1)
            PixelBlock += struct.pack('<B', DoubleIndex)
    return TexType, PaletteBlock, PixelBlock, MipCount


def Write_Tex17():  # Tex17 / Tex18
    PaletteBlock = b''
    PixelBlock = b''
    # Convert PyPNG-Pixels to Int8 List
    AllIntList = []
    for MipPixels in MipPixelList:
        NewPixels = list(MipPixels)
        IntList = []
        for ByteArray in NewPixels:
            for Byte in ByteArray:
                IntList.append(Byte)
        AllIntList.append(IntList)
    # Convert IntList to RGBA Pixels
    AllPixelList = []
    for IntList in AllIntList:
        PixelList = []
        if Alpha == False:
            TexType = 17
            for Value in range(len(IntList)//3):
                PixelList.append([IntList[Value*3+0], IntList[Value*3+1], IntList[Value*3+2]])
        if Alpha == True:
            TexType = 18
            for Value in range(len(IntList)//4):
                PixelList.append([IntList[Value*4+0], IntList[Value*4+1], IntList[Value*4+2], IntList[Value*4+3]])
        AllPixelList.append(PixelList)
    #  Write MipMaps ByteBlock
    MipMaps, MipCount = Create_MipMaps(AllPixelList)
    for Mip in MipMaps:
        for Pixel in Mip:
            if Alpha == False:
                PixelBlock += struct.pack('<BBB', Pixel[0], Pixel[1], Pixel[2])
            if Alpha == True:
                PixelBlock += struct.pack('<BBBB', Pixel[0], Pixel[1], Pixel[2], Pixel[3])
    return TexType, PaletteBlock, PixelBlock, MipCount



def Create_MipMaps(AllPixelList):
    # Calculate Number of MipMaps
    if AutoCreateMipMaps == True and not OriginalMipCount == "1" : 
        MipCounter = 1
        Divider = 1
        MinRes = min(Height, Width)
        while MinRes//Divider > 2 and not MipCounter == 11:     # Limited to 10 MipMaps (This Limit is set by Tex2Png/Png2Tex not by Angel Game Engine)
            MipCounter += 1
            Divider *= 2
    else:
        MipCounter = len(AllPixelList)
    # Split PixelList in Rows
    Divider = 1
    AllMipRows = []
    for PixelList in AllPixelList:
        AllRows = []
        for I in range(Height//Divider):
            Row = []
            RowJump = I*(Width//Divider)
            for Index in range(Width//Divider):
                Row.append(PixelList[RowJump+Index])
            AllRows.append(Row)
        AllMipRows.append(AllRows)
        Divider *= 2
    # Mirror Texture Upside Down if Selected
    if MirrorV == True:
        for AllRows in AllMipRows:
            AllRows.reverse()   
    # Create automatic MipMaps
    if AutoCreateMipMaps == True and not OriginalMipCount == "1" :
        Divider = 1
        AllMipMaps = []
        AllRows = AllMipRows[0]
        for Mip in range(MipCounter):
            MipMap = []
            for H in range(Height//Divider):
                CurrentRow = AllRows[H*Divider]
                for W in range(Width//Divider):
                    MipMap.append(CurrentRow[W*Divider])
            AllMipMaps.append(MipMap)
            Divider *= 2
    # Use custom MipMaps
    else:
        Divider = 1
        AllMipMaps = []
        for Mip in range(MipCounter):
            AllRows = AllMipRows[Mip]
            MipMap = []
            for H in range(Height//Divider):
                CurrentRow = AllRows[H]
                for W in range(Width//Divider):
                    MipMap.append(CurrentRow[W])
            AllMipMaps.append(MipMap)
            Divider *= 2
    return AllMipMaps, MipCounter


        


#******************************************************* Main Script **************************************************************************************************************
InputFolder = PathToSelf+"Input   PNG/"
OutputFolder = PathToSelf+"Output   TEX/"

# 01 02 06 08 09 10 11 14 15 16 17 18 19 20 21 22 24 26     Total
# 01    06 08       11 14 15 16 17 18          22 24 26     Tex2Png
# 01    06          11 14 15 16 17 18                       Png2Tex
Tex01Counter = 0
Tex06Counter = 0
Tex08Counter = 0
Tex11Counter = 0
Tex14Counter = 0
Tex15Counter = 0
Tex16Counter = 0
Tex17Counter = 0
Tex18Counter = 0

FlagList = []
NameList = []
# Read FlagList.txt
if os.path.exists(InputFolder+"FlagList.txt") == True:  # Only if File Exists
    with open(InputFolder+"FlagList.txt", "r") as FileToRead:
        Text = FileToRead.readlines()
        for Line in Text:
            FlagList.append([Line[0:8], Line[9:17], Line[18:26], Line[27:35], Line[36:44], Line[45:53], Line[54:55]])   # Garbage1, Garbage2, Flag1, Flag2, Flag3, Flag4, OriginalMipCount
            NameList.append(Line[56:-1])
        FlagListFound = "Found"
else:
    FlagListFound = "Missing"
    OriginalMipCount = "0"


TotalCounter = 0
InterlaceCounter = 0
ErrorCounter = 0
for Root, Dirs, Files in os.walk(InputFolder):      # per 1 Root / > All SubDir / > All Files
    for File in Files: 
        # Ignore all Files except .tex and .xtex
        if not File[-4:] == ".png" and not File[-4:] == ".PNG":
            continue
        
        if File[-9:-5] == "_Mip":   # Ignore MipMaps
            continue
        
        # Find MipMaps related to PNG (TextureName_Mip1.png)
        PngMipList = [File]         # MainImage first then all MipMaps
        if AutoCreateMipMaps == False:
            for MipExt in ["_Mip1", "_Mip2", "_Mip3", "_Mip4", "_Mip5", "_Mip6", "_Mip7", "_Mip8", "_Mip9"]:
                if File[:-4]+MipExt+File[-4:] in Files:
                    PngMipList.append(File[:-4]+MipExt+File[-4:])
        
        # Open and Read File
        try:
            PngReader = png.Reader(filename=Root+"/"+File)
            Width, Height, Pixels, Metadata = PngReader.read()  # Pixels overiden by MipMaps
        
            Grey, Alpha, Bitdepth = Metadata["greyscale"], Metadata["alpha"], Metadata["bitdepth"]
            # Palette Seperated to avoid Error
            if "palette" in Metadata: 
                Palette = Metadata["palette"]
            else:
                Palette = None
            
            Planes = Metadata["planes"]         # Number of Values per Pixel or "Strides" from Dummiesman (Index for Palette = 1, Greyscale = 1, RGB = 3, RGBA = 4)
            Interlace = Metadata["interlace"]   # 1 == True (Similar to MipMaps but used from Low to High Quality for displaying the PNG during it's download)
            Size = Metadata["size"]             # == Resolution (Width, Height)
            
            # Read Pixels of all MipMaps including MainImage
            MipPixelList = []
            for PngMip in PngMipList:
                PngReader = png.Reader(filename=Root+"/"+PngMip)
                A, B, Pixels, D = PngReader.read()      # Only Pixels are used here
                MipPixelList.append(Pixels)
                
                
        except: 
            print("Unable to open for reading:  ", File)
            ErrorCounter += 1
            continue
        
        # Replace File Extension
        FileName = File[:-4]+FileExt
        RawName = File[:-4]
        
        # Use Flags from FlagList
        if FlagListFound == "Found":
            Index = NameList.index(RawName)
            Flags = FlagList[Index]
            Garbage1, Garbage2, Flag1, Flag2, Flag3, Flag4 = Flags[0], Flags[1], Flags[2], Flags[3], Flags[4], Flags[5]
            OriginalMipCount = Flags[6]
        
        if PrintFileHead == True:
            print()
            print("FileName:  ", File)
            print(f'{Width} x {Height} / Grey: {Grey} / Alpha: {Alpha} / Bitdepth: {Bitdepth}')
            print(f'Planes: {Planes} / Interlace: {Interlace}')
            print("Garbage: ", Garbage1, Garbage2, "Flags: ", Flag1, Flag2, Flag3, Flag4)
            if not Palette == None:
                print(f'Length of Palette: {len(Palette)}')
            
        if Interlace == 1:  # Interlace is not Supported! 
            print("Unable to Convert PNG with Interlace:  ", File)
            InterlaceCounter += 1
            continue
        
        if not Palette == None:
            if len(Palette) > 256:
                print("Palette too big")

        # 01    06          11 14 15 16 17 18                       Png2Tex
        # Write ByteBlocks depending on TexType
        if not Palette == None and Bitdepth == 8 and len(Palette) <= 256 and len(Palette) > 16:     # Tex01 / 14    (From Tex01 / 14)
            TexType, PaletteBlock, PixelBlock, MipCount = Write_Tex01()
#            print("TexType", TexType, "/ ", File)
            if TexType == 1:
                Tex01Counter += 1
            if TexType == 14:
                Tex14Counter += 1
        
        # Tex06 will be Converted as Tex18
        elif Palette == None and Bitdepth == 4 and Alpha == True and Grey == False:                 # Tex06         (From Tex06)   Note: PyPng in Tex2Png does Export Tex06 as 8 Bit instead of 4 Bit !!!
            TexType, PaletteBlock, PixelBlock, MipCount = Write_Tex06()                             #                                    That means the Output PNG is Identical to Tex18.
            print("TexType 06 / ", File)
            Tex06Counter += 1
        
        elif Palette == None and Bitdepth == 8 and Alpha == True and Grey == True:                  # Tex11         (From Tex08 / 11)
            TexType, PaletteBlock, PixelBlock, MipCount = Write_Tex11()
#            print("TexType 11 / ", File)
            Tex11Counter += 1
            
        elif not Palette == None and Bitdepth == 8 and len(Palette) <= 16:                          # Tex15 / 16    (From Tex15 / 16)
            TexType, PaletteBlock, PixelBlock, MipCount = Write_Tex15()
#            print("TexType", TexType, "/ ", File)
            if TexType == 15:
                Tex15Counter += 1
            if TexType == 16:
                Tex16Counter += 1
        
        elif Palette == None and Bitdepth == 8 and Grey == False:                                   # Tex17 / 18     (From Tex17 / 18 / 22 / 24 / 26 and Tex06)
            TexType, PaletteBlock, PixelBlock, MipCount = Write_Tex17()
            if TexType == 17:
#                print("TexType 17 / ", File)
                Tex17Counter += 1
            if TexType == 18:
#                print("TexType 18 / ", File)
                Tex18Counter += 1
            
        else:
            print("Unsupported PNG Type:  ", File)
            ErrorCounter += 1
            continue
        
        

        # Get Directory for TEX Output
        if InputFolder == Root:                 # if File is not in SubDirectory
            ExportFolder = OutputFolder
        else:                                   # Add SubDirectory to Output Folder
            TempLen = len(InputFolder)
            TempFolder = Root[TempLen:]
            ExportFolder = OutputFolder+TempFolder+"/"
            ExportFolder = ExportFolder.replace('\\', "/")      # 1st Input is SubString to Replace / 2nd Input is new Substring
        
        # Create New Directory if needed
        if not os.path.isdir(ExportFolder): 
            os.makedirs(ExportFolder)
        




        # Write TEX File **********************************************************************
        try:
            # Create FileHead
            FileHead = b''
            FileHead += struct.pack('<HHHH', Width, Height, TexType, MipCount)
            FileHead += struct.pack('<BBBBBB', int(Garbage1, 2), int(Garbage2, 2), int(Flag1, 2), int(Flag2, 2), int(Flag3, 2), int(Flag4, 2))     # Garbage1, Garbage2, Flag1, Flag2, Flag3, Flag4
            # Write File
            with open(ExportFolder+FileName, 'wb') as TexFile:
                TexFile.write(FileHead+PaletteBlock+PixelBlock)
            TotalCounter += 1
        except:
            print("Write Error:   ", TexType, File)
            ErrorCounter += 1
           
print()
print("FlagList: " + FlagListFound)
print("Tex01   Files Converted: ", Tex01Counter)
print("Tex06   Files Converted: ", Tex06Counter)
print("Tex08   Files Converted: ", Tex08Counter)
print("Tex11   Files Converted: ", Tex11Counter)
print("Tex14   Files Converted: ", Tex14Counter)
print("Tex15   Files Converted: ", Tex15Counter)
print("Tex16   Files Converted: ", Tex16Counter)
print("Tex17   Files Converted: ", Tex17Counter)
print("Tex18   Files Converted: ", Tex18Counter)
print("Error: ", ErrorCounter, " Conversions Failed !!!")
print("Interlace: ", InterlaceCounter, " Conversions Failed !!!")
print("Total Files Converted:  ", TotalCounter)
