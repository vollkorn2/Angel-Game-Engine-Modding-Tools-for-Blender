This Tool was made by vollkorn2
22.10.2025



Pack .dat File in DAVE Format (Uncompressed) 	from "Angel Game Engine" (AGE) Games / Angel Studios (now: Rockstar San Diego)
Only Red Dead Revolver (PS2) is Tested and only BANKS.DAT, FRONT.DAT, PUPSHOW.DAT and STREAMS.DAT will work (Format = b'DAVE' / Compress = False)
In generel replacing Dave Dat-Files with DAVE Dat-Files works in some situations but unfortunately not in all Cases

Before Running the Script:

1. 	Open Blender 
2. 	Open CompileDat_DAVE v1.1 inside Text Editor 
3. 	Set Variables (Almost on Top of the Script)
	- PathToSelf 		Used to find Output Folder
	- ToDatFolder 		FolderPath to your Files to Pack into .dat (Make Sure the Folder is named as the Dat File   /   Subfolders are not yet supported)
	- FileExt 		Choose between .dat and .zip 	(.zip was never tested   /   .dat or .DAT doesn't matter) 
 	- Format 		Keep b'DAVE' selected (b'Dave' doesn't work)
	- Compress 		Keep False selected (Compression itself is working fine but the Files won't be accepted by the Game)
4. 	Run Script (depending on FileSize and Number of Files the Script will run a few Seconds or up to 30 min. or more)

You can Extract .DAT Files again with ar_extract from LV_Volk