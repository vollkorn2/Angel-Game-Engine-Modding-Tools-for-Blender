#   Pack .dat File in DAVE Format   vollkorn2   (YT: SoGTA in UE5)
#   Supported                       .dat (DAVE)/ .zip (DAVE)
#   Not Supported                   .dat (PK/Dave/Hash) / .ar
#   Angel Game Engine Archive File 	Angel Studios (now: Rockstar San Diego)

#   ToDo:
#   Add Subfolders to FileName Section
#   Figure out how to read/write Dave Format
#   Figure out why compressed DAVE Files are not accepted by the Game
#   Automatisation for writing several .DAT Files in a row

#   v1.1    22.10.2025
#   Added zlib compression      zlib.compress(FileRead, level = 6, wbits = -15)
#   Filename-compression for Dave Format has failed

#   v1.0    19.10.2025

# Games Tested:
# Red Dead Revolver (PS2)
#   Name            Original                    DAVE Uncompressed       DAVE Compressed
#   BANKS.DAT       DAVE Uncompressed           Yes     3 sec           No  but accepted
#   FRONT.DAT       Dave Compressed             Yes     1 sec           No
#   PUPSHOW.DAT     Dave Uncompressed           Yes     8 sec           No  but accepted
#   STREAMS.DAT     DAVE Uncompressed           Yes     11 min          No  but accepted

#   SWAT.DAT        Dave Compressed             No      27 min.         Not Tested
#   PERFNEW.DAT     Dave Compressed             No      8 sec           No


# **********************************************************************************************************************************************************************************************


# All Paths must end with "/" and all other Slashes must be also this direction "/"
#PathToSelf = "D:/This/Could/Be/Your/FilePath/Leading/To/CompileDat_DAVE/"      # Folderpath to CompileDat_DAVE Script

#ToDatFolder = "D:/This/Could/Be/Your/FilePath/DatFilesExtracted/"              # .zip / .dat Files must be extracted in this Folder    (Last FolderName = DAT Name) 

FileExt = ".DAT"        #   ".DAT"      ".dat"      ".ZIP"      ".zip"              zip was never Tested
Format = b'DAVE'        #   b'DAVE'     b'Dave'                                     Dave is not working
Compress = False        # Compress Files as "zlib(level = 6, wbits = -15)"          Compression does work but Files are not accepted by the Game

# **********************************************************************************************************************************************************************************************


def Calc_Size(LenRawBytes):        # Rounds Up each DataBlock to next even 2048 Step
    Count = LenRawBytes/2048
    ExtraByte = 1
    if Count == float(int(Count)):
        ExtraByte = 0
    Count = int(Count)+ExtraByte    # int() always Truncates, so add 1 for next Step (Skip if Number of Bytes already even)
    TotalBytes = Count * 2048
    FillBytes = TotalBytes - LenRawBytes
    return TotalBytes, FillBytes


# **********************************************************************************************************************************************************************************************



import os       # Read/Write Files in Operating System
import struct   # Read Binary Files
import re       # Split Text by Character
import zlib     # Compress Files
import base64   # Compress FileNames (doesn't work)
OutputFolder = PathToSelf+"Output   DAT/"

print("*** Start ********************************************************************************")

NumEntries = 0              # Number of File Entries
LenNameList = 0             # Number of Bytes for FileName Section (Counts from Section Start NameList)
ByteAdressToFileData = 0    # Number of Bytes for FileDataBlock Section (Counts from Section Start FileDataBlock)

FileInfoList = []           # FileName / ByteAdress ToName / ByteAdress ToFileData / Uncompressed Size / Compressed Size
FileNameBlock = b''
FileDataBlocks = b''        # Each File saved together ready to write

# Get All Files
for Root, Dirs, Files in os.walk(ToDatFolder):      # per 1 Root / > All SubDir / > All Files
    for File in Files: 
        with open(Root+"/"+File, 'rb') as FileToPack:
            FileRead = FileToPack.read()
        NumEntries += 1
        UncompressedSize = len(FileRead)
        File = File.encode("utf-8")
        if Compress == True:
            FileRead = zlib.compress(FileRead, level = 6, wbits = -15)
#            File = zlib.compress(File, level = 6, wbits = -15)     # Compress Filenames doesn't work
#        File = base64.b64decode(File)                              # Compress Filenames doesn't work
        CompressedSize = len(FileRead)
        TotalBytes, LenToFill = Calc_Size(len(FileRead))
        FileDataBlocks += FileRead+bytes(LenToFill)
        
        FileNameBlock += File+bytes(1)
        FileInfoList.append([File, LenNameList, ByteAdressToFileData, UncompressedSize, CompressedSize])      # FileName / ByteAdress ToName / ByteAdress ToFileData / Uncompressed File / Compressed File
        LenNameList += len(File)+1              # Length of FileName + 1 empty Byte
        ByteAdressToFileData += TotalBytes      # Compressed Size + Empty Bytes
        

#if Compress == True:   # Compress Filenames doesn't work
#    FileNameBlock = zlib.compress(FileNameBlock, level = 6, wbits = -15)


# Create DAT File       /       All DataBlocks must fill to a 2048 dividable ByteBlock
DatName = re.split(r'/', ToDatFolder)
DatName = DatName[len(DatName)-2]   # Get Last Folder for DAT Name
LenBytesAdressFilled, LenToFillAdress = Calc_Size(NumEntries*16)    # 16 Bytes per Line 
LenNameListFilled, LenToFillName = Calc_Size(LenNameList)

# FileHead
#FileHead = b'DAVE'
FileHead = Format
FileHead += struct.pack('<LLL', NumEntries, LenBytesAdressFilled, LenNameListFilled)
FileHead += bytes(2032)         # +2032 Empty Bytes

# ByteAdress / FileName
LenToDataBlocks = 2048+LenBytesAdressFilled+LenNameListFilled       # Length from Start to 1st FileData (ByteAdress to Files is increment in "ByteAdressList")
ByteAdressBlock = b''
#FileNameBlock = b''
for Line in FileInfoList:
    ByteAdressBlock += struct.pack('<LLLL', Line[1], Line[2]+LenToDataBlocks, Line[3], Line[4])
#    FileNameBlock += Line[0]+bytes(1)      # 1 Empty Byte as Split
ByteAdressBlock += bytes(LenToFillAdress) 
FileNameBlock += bytes(LenToFillName) 

# Write File
with open(OutputFolder+DatName+FileExt, "wb") as FileToWrite:
    FileToWrite.write(FileHead+ByteAdressBlock+FileNameBlock+FileDataBlocks)

print(DatName+FileExt, "is written")
