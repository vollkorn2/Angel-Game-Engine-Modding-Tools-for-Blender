
#   Texture Converter by            vollkorn2   (YT: SoGTA in UE5)
#   Some Code copied from           Murugo      (GitHub: RDR-Proto-Tools)   /   Dummiesman  (Github: AngelStudiosBlenderAddon)
#   Supported                       .tex / .xtex    Tex Type: 01 / 06 / 08 / 11 / 14 / 15 / 16 / 17 / 18 / 22 / 24 / 26 
#   Not Supported                   .fonttex        Tex Type: 02 / 09 / 10 / 19 / 20 / 21
#   Angel Game Engine Textures 	    Angel Studios (now: Rockstar San Diego)

#   v2.4    26.09.2025
#   Minimal Changes for Png2Tex
#   Number of MipMaps limited to 10 (Set by Tex2Png, not by Angel Game Engine)
#   Garbage is now printed as Integer16 and 2 Binary Strings (used for Analysing)

#   v2.3    31.08.2025
#   Final Script Overhaul
#   Combine Similar Functions
#   Use more features of PyPNG: Bitdepth, Palette
#   Bug Fix: Uneven Resolution 33x32 / No Resolution 0x0 / MipMaps for Tex22/24/26
#   DXT3 is now added to DXT_Decompress(_vollkorn2)
#   Alpha Disabled by Flag1 == "00001000" (Midnight Club 1/2)

#   v2.2
#   Change File Reading Method from Murugo-Style to vollkorn2-Style
#   Read and Export MipMaps as seperated .png (Read MipMaps copied from Dummiesman)
#   Inverted PNGs are now Default / AGE seems to handle them as Inverted too
#   Improved TexType06 but still not 100% Correct
#   Tex22/26 Support / Tex24 Beta Support / - all without MipMaps

#   v2.1
#   Mass Extracting with GameFolder (Extracted GameFiles)
#   Count Tex Types and Total Converted Files
#   Lots of Small Changes

#   v2.0 vollkorn2  (Original Script by Murugo)
#   Made to Run inside of Blender
#   Input/Output Folder 
#   PyPng is called by Path (No Installation needed)
#   Tex Type 08 and 11 are now Supported (Greyscale / Alpha Mask)
#   Better Documentation

# Games Tested:
# Red Dead Revolver Prototype 15 Jan 2002   (PS2)
# Red Dead Revolver                         (PS2/Xbox)
# Midnight Club: Street Racing              (PS2)
# Midnight Club II                          (PS2)
# Midnight Club 3 Remix                     (PS2/PSP)
# Test Drive: Offroad Wide Open             (PS2)
# Midtown Madness 2                         (PC)
# Smuggler's Run                            (PS2)
# Smuggler's Run 2                          (PS2)

# **********************************************************************************************************************************************************************************************


# All Paths must end with "/" and all other Slashes must be also this direction "/"
PathToSelf = "D:/This/Could/Be/Your/FilePath/Leading/To/Tex2Png/"    # Folderpath to TexToPng Script

GameFolder = "D:/This/Could/Be/Your/FilePath/GameFilesExtracted/"            # .ar / .zip and .dat Files must be extracted in this Folder

UseMassExtract = True       # Use GameFolder instead of InputFolder
MirrorV = False             # Correct the Reversed Reading of AGE .tex files (Only for Extracting usefull, not for Modding / Depends on .mod Importer)
ExportMipMaps = False       # Create a new .png file for each MipMap "TexName_Mip1.png"   /   used to repack with Png2Tex or to make your own custom MipMaps (Png2Tex can repack all Custom MipMaps)

PrintFileHead = False       # Each .tex File has Resolution, TexType, MipMaps, "Garbage" and Flags. Here you can Print these Values to the System Console. Usefull for Analysing.


# **********************************************************************************************************************************************************************************************

import os       # Read/Write Files in Operating System
import sys      # Add Temporary SystemPath to find Modules shipped with TexToPng
sys.path = [PathToSelf+"3rd Party Modules"]      # This makes PyPNG / DXT_Decompress run without installation
import png      # Create PNG Files
import struct   # Read Binary Files
import re       # 
import io       # DXT Decompression (Bytestring to Stream)

# 18 Total TexTypes
# 01 02 06 08 09 10 11 14 15 16 17 18 19 20 21 22 24 26     Total
# 01    06 08       11 14 15 16 17 18          22 24 26     Tex2Png
# 01    06          11 14 15 16 17 18                       Png2Tex
# Stride = ByteDepth per Pixel (RGBA = Stride 4) / -2 means Stride 0.5 (4 bit Total)

#Tex Type: 01       True        P8          Stride 1        8 Bit Index Palette (256 Colors with RGBA as 4 * Int8) Int8 for Indices

#Tex Type: 02       False       P8A8        Stride 2        To Be Found !!!     [8 Bit Index Palette (256 Colors with RGBA as 4 * Int8) Int8 for Indices + Int8 for Unique Alpha]

#Tex Type: 06       3/4         RGBA4444    Stride 2        RGBA        4 * Int4    (sky.tex has weird Alpha Channel and a big Pink Spot)

#Tex Type: 08       True        A8          Stride 1        A           1 * Int8

#Tex Type: 09       False       A4I4        Stride 1        To Be Found !!!

#Tex Type: 10       False       A8I8        Stride 2        To Be Found !!!

#Tex Type: 11       True        A8          Stride 1        A           1 * Int8

#Tex Type: 14       True        PA8         Stride 1        8 Bit Index Palette (256 Colors with RGBA as 4 * Int8) Int8 for Indices     with Alpha

#Tex Type: 15       True        P4          Stride -2       4 Bit Index Palette (016 Colors with RGBA as 4 * Int8) Int4 for Indices

#Tex Type: 16       True        PA4         Stride -2       4 Bit Index Palette (016 Colors with RGBA as 4 * Int8) Int4 for Indices     With Alpha

#Tex Type: 17       True        RGB888      Stride 3        RGB         3 * Int8

#Tex Type: 18       True        RGBA8888    Stride 4        RGBA        4 * Int8

#Tex Type: 19       False       Z16         Stride 2        Depth / To Be Found !!!

#Tex Type: 20       False       Z24         Stride 3        Depth / To Be Found !!!

#Tex Type: 21       False       Z32         Stride 4        Depth / To Be Found !!!
 
#Tex Type: 22       True        DXT1        Stride -2       DXT1 Compressed

#Tex Type: 24       True        DXT3        Stride 1        DXT3 Compressed

#Tex Type: 26       True        DXT5        Stride 1        DXT5 Compressed

print("*** Start ********************************************************************************")

def Read_Tex01(TexType):    # Tex01 P8 / Tex02 P8A8 / Tex14 PA8      Stride 1 / 1 / 2 8 Bit Index Palette (256 Colors with !!! BGRA !!! as 4 * Int8) Int8 for Indices (+ Int8 for Unique Alpha (Tex02))
    AllRows = []
    ColorPalette = []
    AllIndexRows = []
    # Get Palette and Pixel DataBlock
    PaletteBlock = FileRead[:4*256]     # LimitFirst
    PixelBlock = FileRead[4*256:]       # RemoveFirst
    # Read Palette
    for ColorIndex in range(256):
        Offset = ColorIndex * 4
        B, G, R, A = struct.unpack('<BBBB', PaletteBlock[Offset:Offset+4])  # Remove Offset from Start : (Limit Offset from Start + Number of Bytes) = Outputs Number of Bytes, cut out from FileRead
        if TexType == "Tex01":
            RGB = [R, G, B]
        elif TexType == "Tex14":
            if Flag1[4:5] == "1":   # "00001000"
                RGB = [R, G, B, 255]    # Disable Alpha / Alpha Channel useless for Unknown reason > used in Midnight Club Street Racing
            else:
                RGB = [R, G, B, A]
        ColorPalette.append(RGB)
    
    # Read MipMaps
    MipByteBlocks = Read_MipMaps(PixelBlock)
    Divider = 1
    for ByteBlock in MipByteBlocks:
        MipRows = []
        MipIndexRows = []
        ByteIndex = 0
        for N in range(Height//Divider):
            Row = []
            IndexRow = []
            for N in range(Width//Divider):
                ColorIndex = ByteBlock[ByteIndex]
                IndexRow.append(ColorIndex)
                Row.extend(ColorPalette[ColorIndex])
                ByteIndex += 1
            MipRows.append(Row)
            MipIndexRows.append(IndexRow)
        AllRows.append(MipRows)
        AllIndexRows.append(MipIndexRows)
        Divider *= 2
    return AllRows, ColorPalette, AllIndexRows


def Read_Tex06():               # Stride 2    RGBA        4 * Int4
    AllRows = []
    PixelBlock = FileRead
    # Read MipMaps
    MipByteBlocks = Read_MipMaps(PixelBlock)
    Divider = 1
    for ByteBlock in MipByteBlocks:
        MipRows = []
        ByteIndex = 0
        for N in range(Height//Divider):
            Row = []
            for N in range(Width//Divider):
                RG, BA = struct.unpack('<BB', ByteBlock[ByteIndex:ByteIndex+2]) 
                R = format(RG, '08b')    # To Binary String
                R = int(R[:-4], 2)       # RemoveLast
                G = format(RG, '08b')
                G = int(G[4:], 2)        # RemoveFirst
                B = format(BA, '08b')
                B = int(B[:-4], 2)
                A = format(BA, '08b')
                A = int(A[4:], 2)
                Row.extend([R, G, B, 15])
#                Row.extend([R*17, G*17, B*17, A*17])    # *17 = from 4 bit to 8 bit (0-15 to 0-255)    # Alpha doesn't make sense
                ByteIndex += 2
            MipRows.append(Row)
        AllRows.append(MipRows)
        Divider *= 2
    return AllRows


def Read_Tex08():               # Stride 1    A           1 * Int8 (AlphaMask)
    AllRows = []
    PixelBlock = FileRead
    # Read MipMaps
    MipByteBlocks = Read_MipMaps(PixelBlock)
    Divider = 1
    for ByteBlock in MipByteBlocks:
        MipRows = []
        ByteIndex = 0
        for N in range(Height//Divider):
            Row = []
            for N in range(Width//Divider):
                A = ByteBlock[ByteIndex]
                Row.extend([255, A])   # White Color with Alpha from File
                ByteIndex += 1
            MipRows.append(Row)
        AllRows.append(MipRows)
        Divider *= 2
    return AllRows


def Read_Tex09():               # A4I4        Stride 1    To Be Found !!!
    print("Unsupported Tex Type:  ", TexType, " / ", File)


def Read_Tex10():               # A8I8        Stride 2    To Be Found !!!
    print("Unsupported Tex Type:  ", TexType, " / ", File)


def Read_Tex15(TexType):        # Tex15 P4 / Tex16 PA4  Stride -2   4 Bit Index Palette (016 Colors with RGBA as 4 * Int8) Int4 for Indices
    AllRows = []
    ColorPalette = []
    AllIndexRows = []
    # Get Palette and Pixel DataBlock
    PaletteBlock = FileRead[:4*16]     # LimitFirst
    PixelBlock = FileRead[4*16:]       # RemoveFirst
    # Read Palette
    for ColorIndex in range(16):
        Offset = ColorIndex * 4
        B, G, R, A = struct.unpack('<BBBB', PaletteBlock[Offset:Offset+4])  # Remove Offset from Start : (Limit Offset from Start + Number of Bytes) = Outputs Number of Bytes, cut out from FileRead
        if TexType == "Tex15":
            RGB = [R, G, B] 
        elif TexType == "Tex16":
            RGB = [R, G, B, A]
        ColorPalette.append(RGB)
    
    # Read MipMaps
    MipByteBlocks = Read_MipMaps(PixelBlock)
    Divider = 1
    for ByteBlock in MipByteBlocks:
        # Read all Indices first to avoid bug with uneven Resolution (like 33x32)
        IndexList = []
        for Byte in ByteBlock:                      # Cut each Byte in Half to get 2x Int4
            Binary = format(Byte, '08b')            # To Binary String
            IndexList.append(int(Binary[4:], 2))    # RemoveFirst
            IndexList.append(int(Binary[:-4], 2))   # RemoveLast
        MipRows = []
        MipIndexRows = []
        ByteIndex = 0
        for N in range(Height//Divider):
            Row = []
            IndexRow = []
            for N in range(Width//Divider): 
                ColorIndex = IndexList[ByteIndex]
                IndexRow.append(ColorIndex)
                Row.extend(ColorPalette[ColorIndex])
                ByteIndex += 1
            MipRows.append(Row)
            MipIndexRows.append(IndexRow)
        AllRows.append(MipRows)
        AllIndexRows.append(MipIndexRows)
        Divider *= 2
    return AllRows, ColorPalette, AllIndexRows


def Read_Tex17(TexType):               # Tex17 RGB888 / Tex18 RGBA8888  Stride 3 / 4    RGB / RGBA         3 * Int8 / 4 * Int8
    AllRows = []
    PixelBlock = FileRead
    # Read MipMaps
    MipByteBlocks = Read_MipMaps(PixelBlock)
    Divider = 1
    for ByteBlock in MipByteBlocks:
        MipRows = []
        ByteIndex = 0
        for N in range(Height//Divider):
            Row = []
            for N in range(Width//Divider):
                if TexType == "Tex17":
                    R, G, B = struct.unpack('<BBB', ByteBlock[ByteIndex:ByteIndex+3])
                    Row.extend([R, G, B])
                    ByteIndex += 3
                elif TexType == "Tex18":
                    R, G, B, A = struct.unpack('<BBBB', ByteBlock[ByteIndex:ByteIndex+4])
                    Row.extend([R, G, B, A])
                    ByteIndex += 4
            MipRows.append(Row)
        AllRows.append(MipRows)
        Divider *= 2
    return AllRows


def Read_Tex19():               # Z16         Stride 2    Depth / To Be Found !!!
    print("Unsupported Tex Type:  ", TexType, " / ", File)


def Read_Tex20():               # Z24         Stride 3    Depth / To Be Found !!!
    print("Unsupported Tex Type:  ", TexType, " / ", File)


def Read_Tex21():               # Z32         Stride 4    Depth / To Be Found !!!
    print("Unsupported Tex Type:  ", TexType, " / ", File)


def Read_Tex22(TexType):
    AllRows = []
    PixelBlock = FileRead
    # Read MipMaps
    DxtByteBlocks = Read_MipMaps(PixelBlock)
    MipByteBlocks = []
    from dxt_decompress_withDXT3 import DXTBuffer_Voll
    
    Divider = 1
    for ByteBlock in DxtByteBlocks:
        DecompressedData = None     # Reset
        Stream = io.BytesIO(ByteBlock)
        Buf = DXTBuffer_Voll(Width//Divider, Height//Divider)
        if TexType == "Tex22":
            DecompressedData = Buf.DXT1Decompress(Stream)
        elif TexType == "Tex24":
            DecompressedData = Buf.DXT3Decompress(Stream)
        elif TexType == "Tex26":
            DecompressedData = Buf.DXT5Decompress(Stream)
        MipByteBlocks.append(DecompressedData)
        Divider *= 2
    
    
    Divider = 1
    for ByteBlock in MipByteBlocks:
        MipRows = []
        ByteIndex = 0
        for N in range(Height//Divider):
            Row = []
            for N in range(Width//Divider):
                R, G, B, A = struct.unpack('<BBBB', ByteBlock[ByteIndex:ByteIndex+4]) 
                if Flag1[4:5] == "1":   # "00001000"
                    Row.extend([R, G, B, 255])  # Disable Alpha / Alpha Channel possibly manipulated by TimeCycle Script > Used in Midnight Club II Street Textures (Weather Dependent)
                else:
                    Row.extend([R, G, B, A])
                ByteIndex += 4
            MipRows.append(Row)
        AllRows.append(MipRows)
        Divider *= 2
    return AllRows



def Read_MipMaps(PixelBlock):
    MipByteBlocks = []
    Strides = (0,1,2,None,None,None,2,None,1,1,2,1,None,None,1,-2,-2,3,4,2,3,4,-2,None,1,None,1)    # BitDepth as Number of Bytes per Color for each TexType 0-26 (None are Strange/Unkown TexTypes) (-2 = 0.5)
    Divider = 1     # (Doubled for each MipMap)
    if MipMaps == 0:
        print("!!! No MipMaps !!!")
    for MipIndex in range(MipMaps):     # (Index 0 = MainImage)
        # Calculate MipSize
        TempHeight = Height // Divider
        TempWidth = Width // Divider
        if TempHeight == 2 or TempWidth == 2: # Stop creating MipMaps with only 2x2 Pixel
            break
        Divider *= 2
        
        # Strides / Number of Bytes per MipMap
        Stride = Strides[TexType]
        if Stride < 0:
            MipByteLen = (TempHeight * TempWidth) // -Stride   # Half Byte per Pixel
        else:
            MipByteLen = (TempHeight * TempWidth) * Stride
        # Get Data Block for MipMap    
        MipByteBlocks.append(PixelBlock[:int(MipByteLen)])  # LimitFirst
        PixelBlock = PixelBlock[int(MipByteLen):]           # DeleteFirst
    return MipByteBlocks
        


#******************************************************* Main Script **************************************************************************************************************
InputFolder = PathToSelf+"Input   TEX/"
OutputFolder = PathToSelf+"Output   PNG/"
if UseMassExtract == True:
    InputFolder = GameFolder
    
AllIndexRows = []

# 01 02 06 08 09 10 11 14 15 16 17 18 19 20 21 22 24 26     Total
# 01    06 08       11 14 15 16 17 18          22 24 26     Tex2Png
# 01    06          11 14 15 16 17 18                       Png2Tex
Tex01Counter = 0
Tex02Counter = 0
Tex06Counter = 0
Tex08Counter = 0
Tex09Counter = 0
Tex10Counter = 0
Tex11Counter = 0
Tex14Counter = 0
Tex15Counter = 0
Tex16Counter = 0
Tex17Counter = 0
Tex18Counter = 0
Tex19Counter = 0
Tex20Counter = 0
Tex21Counter = 0
Tex22Counter = 0
Tex24Counter = 0
Tex26Counter = 0

TotalCounter = 0
ErrorCounter = 0
ResOxOCounter = 0
for Root, Dirs, Files in os.walk(InputFolder):      # per 1 Root / > All SubDir / > All Files
    for File in Files: 
        # Ignore all Files except .tex and .xtex
        if not File[-4:] == ".tex" and not File[-5:] == ".xtex":
            continue
        
        # Open and Read File
        try: 
            with open(Root+"/"+File, 'rb') as TexFile:
                FileRead = TexFile.read()
        except:
            print("Unable to open for reading:  ", File)
            ErrorCounter += 1
            continue

        # Read FileHead
        Width, Height, TexType = struct.unpack('<HHH', FileRead[:6])        # "<" = Little Endian, "H" = Int16, "L" = Int32   /   :6 (Limit to first 6 Characters)
        MipMaps, Garbage, Flags = struct.unpack('<HHL', FileRead[6:14])     # Remove First 6 / Limit to First 14
        Garbage1 = format(FileRead[8], '08b')                               # Byte to Binary Code
        Garbage2 = format(FileRead[9], '08b')
        Flag1 = format(FileRead[10], '08b')
        Flag2 = format(FileRead[11], '08b')
        Flag3 = format(FileRead[12], '08b')
        Flag4 = format(FileRead[13], '08b')
        
        FileRead = FileRead[14:]    # Remove FileHead from Buffer
        
        # Debug Options
#        if not TexType == 26:       # Limit to Specific TexType
#            continue
        
#        if not Flag1[4:5] == "1":   # "00001000"   Limit to Specific Flag
#            continue
        
        # Block if Resolution is 0x0
        if Height == 0 or Width == 0:
            print("Resolution = 0x0, File Skipped: ", File)
            ResOxOCounter += 1
            continue
      
        if PrintFileHead == True:
            print()
            print("FileName:  ", File)
            print(f'{Width} x {Height}   TexType: {TexType}   MipMaps: {MipMaps}   Garbage: {Garbage}')
            print("Garbage: ", Garbage1, Garbage2, "Flags: ", Flag1, Flag2, Flag3, Flag4)
        
        
        
        # 01 02 06 08 09 10 11 14 15 16 17 18 19 20 21 22 24 26     Total
        # 01    06 08       11 14 15 16 17 18          22 24 26     Tex2Png
        # 01    06          11 14 15 16 17 18                       Png2Tex
        # Get Texture Data depending on TexType
        if TexType == 1:    # 0x1
            AllRows, ColorPalette, AllIndexRows = Read_Tex01("Tex01") 
            UsePallette, BitDepth, Alpha, Grey = True, 8, False, False
#            print(TexType, " / ", File)
            Tex01Counter += 1
        
        elif TexType == 2:    # 0x2
            print("Unsupported Tex Type:  ", TexType, " / ", File)
            continue    # **********************
            AllRows, ColorPalette, AllIndexRows = Read_Tex01("Tex02") 
            UsePallette, BitDepth, Alpha, Grey = True, 8, True, False
#            print(TexType, " / ", File)
            Tex02Counter += 1
            
        elif TexType == 6:    # 0x6
            AllRows = Read_Tex06()
            UsePallette, BitDepth, Alpha, Grey = False, 4, True, False
#            print(TexType, " / ", File)
            Tex06Counter += 1
        
        elif TexType == 8:    # 0x8
            AllRows = Read_Tex08()      # 08 and 11 are Identical
            UsePallette, BitDepth, Alpha, Grey = False, 8, True, True
#            print(TexType, " / ", File)
            Tex08Counter += 1
        
        elif TexType == 9:    # 0x9
            Read_Tex09()
            continue    # **********************
            UsePallette, BitDepth, Alpha, Grey = False, 4, True, False
#            print(TexType, " / ", File)
            Tex09Counter += 1
        
        elif TexType == 10:    # 0xA
            Read_Tex10()
            continue    # **********************
            UsePallette, BitDepth, Alpha, Grey = False, 8, True, False
#            print(TexType, " / ", File)
            Tex10Counter += 1
        
        elif TexType == 11:     # 0xB
            AllRows = Read_Tex08()      # 08 and 11 are Identical
            UsePallette, BitDepth, Alpha, Grey = False, 8, True, True
#            print(TexType, " / ", File)
            Tex11Counter += 1

        elif TexType == 14:     # 0xE
            AllRows, ColorPalette, AllIndexRows = Read_Tex01("Tex14")
            UsePallette, BitDepth, Alpha, Grey = True, 8, False, False  # Alpha must be False when using Palette (PyPNG)
#            print(TexType, " / ", File)
            Tex14Counter += 1
            
        elif TexType == 15:     # 0xF
            AllRows, ColorPalette, AllIndexRows = Read_Tex15("Tex15") 
            UsePallette, BitDepth, Alpha, Grey = True, 8, False, False
#            print(TexType, " / ", File)
            Tex15Counter += 1
        
        elif TexType == 16:     # 0x10
            AllRows, ColorPalette, AllIndexRows = Read_Tex15("Tex16") 
            UsePallette, BitDepth, Alpha, Grey = True, 8, False, False  # Alpha must be False when using Palette (PyPNG)
#            print(TexType, " / ", File)
            Tex16Counter += 1
        
        elif TexType == 17:     # 0x11
            AllRows = Read_Tex17("Tex17") 
            UsePallette, BitDepth, Alpha, Grey = False, 8, False, False
#            print(TexType, " / ", File)
            Tex17Counter += 1

        elif TexType == 18:  # 0x12
            AllRows = Read_Tex17("Tex18") 
            UsePallette, BitDepth, Alpha, Grey = False, 8, True, False
#            print(TexType, " / ", File)
            Tex18Counter += 1
        
        elif TexType == 19:    # 0x13
            Read_TexType19
            continue    # **********************
            UsePallette, BitDepth, Alpha, Grey = False, 8, False, False
#            print(TexType, " / ", File)
            Tex19Counter += 1
        
        elif TexType == 20:    # 0x14
            Read_TexType20
            continue    # **********************
            UsePallette, BitDepth, Alpha, Grey = False, 8, False, False
#            print(TexType, " / ", File)
            Tex20Counter += 1
        
        elif TexType == 21:    # 0x15
            Read_TexType21
            continue    # **********************
            UsePallette, BitDepth, Alpha, Grey = False, 8, False, False
#            print(TexType, " / ", File)
            Tex21Counter += 1
        
        elif TexType == 22:    # 0x16
            AllRows = Read_Tex22("Tex22") 
            UsePallette, BitDepth, Alpha, Grey = False, 8, True, False
#            print(TexType, " / ", File)
            Tex22Counter += 1
        
        elif TexType == 24:    # 0x18
            AllRows = Read_Tex22("Tex24") 
            UsePallette, BitDepth, Alpha, Grey = False, 8, True, False
#            print(TexType, " / ", File)
            Tex24Counter += 1
        
        elif TexType == 26:    # 0x1A
            AllRows = Read_Tex22("Tex26") 
            UsePallette, BitDepth, Alpha, Grey = False, 8, True, False
#            print(TexType, " / ", File)
            Tex26Counter += 1

        else:
            print("Unsupported Tex Type:  ", TexType, " / ", File)
            ErrorCounter += 1
            continue



        # Mirror Texture Upside Down if Selected
        if MirrorV == True: 
            for Rows in AllRows:
                Rows.reverse()
            for IndexRows in AllIndexRows:
                IndexRows.reverse()
        
        # Get Directory for PNG Output
        if InputFolder == Root:                 # if File is not in SubDirectory
            ExportFolder = OutputFolder
        else:                                   # Add SubDirectory to Output Folder
            TempLen = len(InputFolder)
            TempFolder = Root[TempLen:]
            ExportFolder = OutputFolder+TempFolder+"/"
            ExportFolder = ExportFolder.replace('\\', "/")      # 1st Input is SubString to Replace / 2nd Input is new Substring
        
        # Create New Directory if needed
        if not os.path.isdir(ExportFolder): 
            os.makedirs(ExportFolder)
        
        # Remove File Extension
        if File[-4:] == ".tex":
            File = File[:-4]
        if File[-5:] == ".xtex":
            File = File[:-5]
        NewFile = File



        # Write PNG File **********************************************************************
        try:
            Divider = 1
            Counter = 0
            for Rows in AllRows: # For MipMap
                MipWidth = Width // Divider
                MipHeight = Height // Divider
                if not Counter == 0 and Counter < 10:
                    NewFile = File + "_Mip" + str(Counter)
                    if ExportMipMaps == False:
                        continue
                
                with open(ExportFolder+NewFile+".png", 'wb+') as PngFile:
                    if UsePallette == True:
                        WriteFile = png.Writer(width = MipWidth, height = MipHeight, bitdepth = BitDepth, greyscale = Grey, alpha = Alpha, palette = ColorPalette)
                        WriteFile.write(PngFile, AllIndexRows[Counter])
                    else:
                        WriteFile = png.Writer(width = MipWidth, height = MipHeight, bitdepth = BitDepth, greyscale = Grey, alpha = Alpha)
                        WriteFile.write(PngFile, Rows)
                Divider *= 2
                Counter += 1
                TotalCounter += 1
        except:
            print("Write Error:   ", TexType, File)
            ErrorCounter += 1
           
print()
print("Tex01   Files Converted: ", Tex01Counter)
print("Tex02   Files Converted: ", Tex02Counter, "   Not Supported")
print("Tex06   Files Converted: ", Tex06Counter)
print("Tex08   Files Converted: ", Tex08Counter)
print("Tex09   Files Converted: ", Tex09Counter, "   Not Supported")
print("Tex10   Files Converted: ", Tex10Counter, "   Not Supported")
print("Tex11   Files Converted: ", Tex11Counter)
print("Tex14   Files Converted: ", Tex14Counter)
print("Tex15   Files Converted: ", Tex15Counter)
print("Tex16   Files Converted: ", Tex16Counter)
print("Tex17   Files Converted: ", Tex17Counter)
print("Tex18   Files Converted: ", Tex18Counter)
print("Tex19   Files Converted: ", Tex19Counter, "   Not Supported")
print("Tex20   Files Converted: ", Tex20Counter, "   Not Supported")
print("Tex21   Files Converted: ", Tex21Counter, "   Not Supported")
print("Tex22   Files Converted: ", Tex22Counter)
print("Tex24   Files Converted: ", Tex24Counter)
print("Tex26   Files Converted: ", Tex26Counter)
print("Error: ", ErrorCounter, " Conversions Failed !!!")
print("No Resolution: ", ResOxOCounter, " Files Skipped !!!")
print("Total Files Converted:  ", TotalCounter)
